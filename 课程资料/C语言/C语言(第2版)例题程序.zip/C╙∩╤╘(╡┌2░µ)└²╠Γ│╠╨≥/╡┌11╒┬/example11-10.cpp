#include <stdio.h>

void main()
{
  union
  {
	char ch;
	short a;
	long  L;
  } d = {0xFFF1F2F341};

  printf("d.ch = %c  d.a = %X  d.L = %X\n",d.ch,d.a,d.L);
  d.a++;
  printf("d.ch = %c  d.a = %X  d.L = %X\n",d.ch,d.a,d.L);

}