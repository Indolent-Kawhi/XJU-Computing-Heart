#include <stdio.h>
	
void main()
{
  int a = 10, b = 100;
  float f = 2;
	
  printf("a = %d, b = %d\n", f, b);
  printf("a = %f, b = %d\n", a, b);
  printf("a = %ld, b = %d\n", 120, b);
}
