#include  <stdio.h>
	 
void main()
{
 char ch;
 int x;
	
 ch = 80 + 50;
 x = 80 + 50;
 printf("ch = %d\n", ch);
 printf("x = %d\n", x);
}
