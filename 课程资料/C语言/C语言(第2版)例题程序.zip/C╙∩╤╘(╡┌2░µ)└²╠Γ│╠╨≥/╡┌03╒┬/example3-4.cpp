#include  <stdio.h>
	
void main()
{
 printf("\101 \x42 C\n");
 printf("I say:\"How are you?\"\n");
 printf("\\C Program\\\n");
 printf("Visual \'C\'\n");
 printf("Y\b=\n");   
}
