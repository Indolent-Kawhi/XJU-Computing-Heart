#include  <stdio.h>
	
void main()
{ 
  char  *pstr = "I Love China!"; 

  printf("%s", pstr);
}
