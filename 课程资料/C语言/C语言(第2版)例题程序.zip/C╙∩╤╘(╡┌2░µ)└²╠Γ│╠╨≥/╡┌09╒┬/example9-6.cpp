#include  <stdio.h>
	
void main()
{ 
  char  *pstr = "I Love China!"; 

  for(; *pstr != '\0'; pstr++) 
    printf("%c", *pstr);
}
